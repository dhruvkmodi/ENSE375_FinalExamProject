package com.uregina.app;

/**
 * am/pm enumerator
 *
 */
public enum AmPm 
{
    am,
	pm
}
