package com.uregina.exceptions;
import java.io.*;
/**
 * Hello world!
 *
 */
public class InvalidTimeException extends Exception{
    public InvalidTimeException(){
		super("Invalid Time");
	}
}